class Charge < ApplicationRecord
  belongs_to :campany
end
