class Company < ApplicationRecord
    has_many :charge
end
