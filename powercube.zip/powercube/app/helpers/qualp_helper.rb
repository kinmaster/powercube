module QualpHelper
end
