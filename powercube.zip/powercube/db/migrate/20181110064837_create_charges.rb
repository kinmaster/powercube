class CreateCharges < ActiveRecord::Migration[5.2]
  def change
    create_table :charges do |t|
      t.float :weight
      t.string :source
      t.string :destiny
      t.float :distance
      t.float :value
      t.integer :axes
      t.references :campany, foreign_key: true

      t.timestamps
    end
  end
end
