require 'test_helper'

class QualpControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get qualp_index_url
    assert_response :success
  end

end
